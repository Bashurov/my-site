<?php
/**
 * Template part for displaying page content in page.php.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package default
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="container">
		<header class="entry-header">
			<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
		</header><!-- .entry-header -->
		<div class="post">
				<div class="row">
					<div class="col-md-8">
						<p class="col-md-4">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptate optio numquam soluta reprehenderit cupiditate maxime repellendus quasi quibusdam ipsum praesentium reiciendis dicta, maiores voluptates deserunt similique id, error asperiores autem nam magni ad. Vitae, facilis nam voluptate eligendi est eos deleniti! Ipsa impedit doloribus accusantium, placeat vel ducimus fugit nemo laborum illum. Consequatur sint, quam unde. Optio dolorum et fugit officia repellat labore est corrupti minima eaque, doloremque iste at saepe pariatur, vel eos ipsam dolore ipsum nostrum dicta reiciendis! Rem soluta quia delectus quaerat amet nemo nisi odit sunt reprehenderit sequi aperiam quod sint, velit tempora quam ullam. Labore.</p>
						<div class="col-md-4">
							<p class="col-md-12">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptate optio numquam soluta reprehenderit cupiditate maxime repellendus quasi quibusdam ipsum praesentium reiciendis dicta, maiores voluptates deserunt similique id, error asperiores autem nam magni ad. Vitae, facilis nam voluptate eligendi est eos deleniti! Ipsa impedit doloribus accusantium, placeat vel ducimus fugit nemo laborum illum. Consequatur sint, quam unde. Optio dolorum et fugit officia repellat labore est corrupti minima eaque, doloremque iste at saepe pariatur, vel eos ipsam dolore ipsum nostrum dicta reiciendis! Rem soluta quia delectus quaerat amet nemo nisi odit sunt reprehenderit sequi aperiam quod sint, velit tempora quam ullam. Labore.</p>
							<p class="col-md-12">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptate optio numquam soluta reprehenderit cupiditate maxime repellendus quasi quibusdam ipsum praesentium reiciendis dicta, maiores voluptates deserunt similique id, error asperiores autem nam magni ad. Vitae, facilis nam voluptate eligendi est eos deleniti! Ipsa impedit doloribus accusantium, placeat vel ducimus fugit nemo laborum illum. Consequatur sint, quam unde. Optio dolorum et fugit officia repellat labore est corrupti minima eaque, doloremque iste at saepe pariatur, vel eos ipsam dolore ipsum nostrum dicta reiciendis! Rem soluta quia delectus quaerat amet nemo nisi odit sunt reprehenderit sequi aperiam quod sint, velit tempora quam ullam. Labore.</p>
						</div>
						<div class="col-md-4">
							<p class="col-md-12">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Natus commodi, eos id, ad amet debitis inventore alias nesciunt similique sunt.</p>
							<p class="col-md-12">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deserunt, laborum laboriosam quaerat magni praesentium velit necessitatibus tenetur molestiae, maxime autem.</p>
							<p class="col-md-12">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deserunt, laborum laboriosam quaerat magni praesentium velit necessitatibus tenetur molestiae, maxime autem.</p>
							<p class="col-md-12">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deserunt, laborum laboriosam quaerat magni praesentium velit necessitatibus tenetur molestiae, maxime autem.</p>
						</div>
					</div>
					<div class="col-md-4">
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consequuntur, soluta sit fugit vel quia doloremque, est laborum necessitatibus voluptas cum voluptatem, quas ipsa cumque nostrum quidem, perferendis maxime placeat eaque! Consectetur vero, quo dolor quos et ab quisquam! Atque aperiam doloribus maxime quia mollitia et, ipsam? Enim possimus, aspernatur dolor a quam illum id pariatur nemo error accusamus repudiandae accusantium provident, hic modi molestias, soluta reprehenderit at consectetur nostrum. Voluptatibus quibusdam dolore cum amet aperiam non autem error quis maiores ipsa impedit nostrum tenetur obcaecati nulla laborum accusamus, totam assumenda ad quisquam. Suscipit saepe perferendis eligendi. Maxime perspiciatis aliquid inventore libero, consequuntur possimus quos? Illum repellat voluptas libero nobis fuga totam laboriosam dignissimos dolores amet nihil nesciunt eveniet voluptatem praesentium ab incidunt beatae commodi dolorum itaque tempore, blanditiis error iure. Minus voluptates recusandae dolorem alias quae, culpa voluptas illum quas. Facere ipsam similique aspernatur laboriosam rerum molestias aperiam quae accusantium fugiat ea commodi, aut necessitatibus reprehenderit. Facere quaerat ea id sint unde, illum doloribus! Beatae velit commodi iste cum, dicta saepe. Atque repudiandae eveniet sequi, velit eligendi itaque quisquam! Fuga, architecto, dicta. Quia, odit! Ad minus expedita culpa in consequuntur veritatis labore tempore quis quaerat numquam! Rem culpa, fuga minus.</p>
					</div>
				</div>
			</div>
		</div>

	<div class="entry-content">
		<?php the_content(); ?>
		<?php
			wp_link_pages( array(
				'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'default' ),
				'after'  => '</div>',
			) );
		?>
	</div><!-- .entry-content -->

	<footer class="entry-footer">
		<?php edit_post_link( esc_html__( 'Edit', 'default' ), '<span class="edit-link">', '</span>' ); ?>
	</footer><!-- .entry-footer -->
</article><!-- #post-## -->

