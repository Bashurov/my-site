=== WP Database Backup ===
Contributors: Prashant Walke
Donate link:https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&amp;hosted_button_id=387BZU5UNQ4LA	
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: Database backup,db backup ,backup, WordPress Database Backup, WP db backup,wp database backup,wp backup,wordpress backup, mysql backup,automatically database backup,website backup,website database backup,restore database backup,Store database backup on dropbox,ftp,email notification.
Requires at least: 3.1+
Tested up to: 4.3
Stable tag: trunk

WP Database Backup plugin helps you to create Database Backup and Restore Database Backup easily on single click.Manual or automated backups.

== Description ==

WP Database Backup plugin helps you to create Database Backup and Restore Database Backup easily on single click.Manual or Automated Database Backups And also store database backup on safe place- dropbox,FTP,Email

<b> Features included </b>
<ul>
<li>Create Database Backup
WP Database Backup plugin helps you to create Database Backup easily on single click.</li>

<li>Autobackup
Backup automatically on a repeating schedule</li>

<li>Download backup file direct from your WordPress dashboard</li>

<li>Easy To Install(Very easy to use)
WP Database Backup is super easy to install. </li>

<li>Simple to configure(very less configuration), less than a minute.</li>

<li>Restore Database Backup
WP Database Backup plugin helps you to Restore Database Backup easily on single click.</li>

<li>Store database backup on safe place- dropbox,FTP,Email</li>

<li>Database backup list pagination</li>
<li>Search backup from list(Date/ Database Size)</li>
<li>Sort backup list (Date/ Database Size)</li>
<li>Save database backup file in zip format on local server And Send database backup file to destination in zip format</li>
</ul>
<br><b>Few of the Key Features :</b>
<ul>
<li>Database Backup easily on single click.</li>
<li>Autobackup.</li>
<li>Restore Database Backup easily on single click.</li>
<li>Store database backup on safe place- dropbox,FTP,Email.</li>
<li>Pagination.</li>
<li>Search and sort database backup feature.</li>
</ul>
<a href="http://www.wpseeds.com/product/wp-all-backup/" target="_blank">Get Pro 'WP All Backup' Plugin</a>
<p>WP All Backup will backup and restore your entire site at will, complete with FTP &amp; S3 integration</p>
<h2>Features</h2>
<ul>
<li class="col-md-3">Complete Backup</li>
<li class="col-md-3">Only Selected file Backup</li>
<li class="col-md-3">ZipArchive</li>
<li class="col-md-3">PclZip</li>
<li class="col-md-3">Scheduled backups</li>
<li class="col-md-3">Set backup interval</li>
<li class="col-md-3">Manual backup</li>
<li class="col-md-3">Multisite compatible</li>
<li class="col-md-3">Backup entire site</li>
<li class="col-md-3">Include media files</li>
<li class="col-md-3">Exclude specific files</li>
<li class="col-md-3">Downloadable log files</li>
<li class="col-md-3">Simple one-click restore</li>
<li class="col-md-3">Set number of backups to store</li>
<li class="col-md-3">Automatically remove oldest backup</li>
<li class="col-md-3">Amazon S3 integration</li>
<li class="col-md-3">FTP and SFTP integration</li>
<li class="col-md-3">Server info quick view</li>
<li class="col-md-3">Support</li>
</ul>
== Installation ==
1. Download the plugin file, unzip and place it in your wp-content/plugins/ folder. You can alternatively upload it via the WordPress plugin backend.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. WP Database Backup menu will appear in Dashboard->Tool->WP-DB-Backup. Click on it & get started to use.
4. Refer to the for <a href=" http://www.wpseeds.com/wp-database-backup/">More Information</a>.

== Screenshots ==

screenshot1.jpeg
screenshot2.jpeg
screenshot3.jpeg
screenshot4.jpeg

Refer to the for <a href=" http://www.wpseeds.com/wp-database-backup/">Screenshots and More Information</a>.

== Changelog ==

= 1.0.0 = 
*Plugin Created

= 2.0 = 
*Restore Database Backup on singe click
*Change look and feel

= 2.1 = 
*Store Database Backup FTP,Dropbox,Email
*Email Notification
*fixed bug: Warning: Illegal offset type in /wp-admin/includes/template.php
*Fixed bug: Warning: Illegal string offset 'enable_autobackups

= 2.1.1 = 
*Fixed bug: Conflict issue with Disqus Comments System, NextGen Gallery etc.

= 2.1.2 = 
*Fixed Dropbox issue ( it saves me a "backup" that weight 0KB.)

= 2.1.3 = 
*Fixed Vulnerability

= 2.2 = 
*Added new Feature
<br>Database backup list pagination
<br>Search backup (Date/ Database Size)
<br>Sort backup list (Date/ Database Size)

= 2.3 = 
<br>Added new tab- Database information.
<br>Include random number in the file name(Improve security).
<br>Added .htaccess file in db-backup directory for prevent database dump listing(Improve security).

= 2.4 = 
<br>Added Hourly Auto Database Backup Frequency
<br>Added Advance Feature Tab.

= 3.0 = 
<br>Added log message.
<br>Send database backup to destination in zip format.
<br>Download database backup file in zip format.
<br>Resoled Database information tab issue.

= 3.1 = 
<br>Added Support and Documantation link in help section.
<br>Resolved .htasses file issue(remove create .htasses file code).

= 3.2 = 
<br>Added Setting Tab.
<br>Added Feature:Minimum number of Local Database Backups(Setting Tab).
<br>Added Feature:Enable Error Log(Setting Tab).
<br>Resolved Error: Undefined index: page 
<br>Changes in Email Notification template.

= 3.3 = 
<br>New Feature : Save database backup file in zip format on local server.

= 3.4 = 
<br>Improve security(CSRF protection): Validate that the contents of the form request came from the current site and not somewhere else.

== Frequently Asked Questions ==

 Q-How to  create database Backup?
 <br>Follow the steps listed below to Create Database Backup

 <br>Create Backup:
  <br>1) Click on Create New Database Backup
  <br>2) Download Database Backup file.
  
 Q-How to restore database backup?
  <br>Restore Backup:
  <br>Click on Restore Database Backup 
  
  <br>OR

  <br>1)Login to phpMyAdmin
  <br>2)Click Databases and select the database that you will be importing your data into.
  <br>3)Across the top of the screen will be a row of tabs. Click the Import tab.
  <br>4)On the next screen will be a location of text file box, and next to that a button named Browse.
  <br>5)Click Browse. Locate the backup file stored on your computer.
  <br>6)Click the Go button

 Q-Always get an empty (0 bits) backup file?
 <br>Ans-This is generally caused by an access denied problem.
 <br>You don't have permission to write in the wp-content/uploads. 
 <br>Please check if you have the read write permission on the folder.
 
 Q.want more featur?
 If you want more feature then
 Drop Mail :walke.prashant28@gmail.com
  
== Upgrade Notice ==

= 3.4 = 
Improve security(CSRF protection): Validate that the contents of the form request came from the current site and not somewhere else.


== Official Site ==
For <a href="walkeprashant.wordpress.com/wp-database-backup/">More Information</a> Or Advanced feature drop mail:walke.prashant28@gmail.com