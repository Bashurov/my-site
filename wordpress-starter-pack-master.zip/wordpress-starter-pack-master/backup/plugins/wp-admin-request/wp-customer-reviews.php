<?php
/*
 * Plugin Name: WP admin request
 * Description: plugins for show db data in ad
 * Version: 1
 * Author: navinweb
 * Author URI: www.navinweb.net
 * License: GNU General Public License
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 */

add_action('wp_ajax_preorder', 'preorder');
add_action('wp_ajax_nopriv_preorder', 'preorder'); 

function preorder(){   
    global $wpdb;    
 
    $date_time = date('Y-m-d H:i:s',strtotime("+3 hours"));
 
    if($_SERVER['REQUEST_METHOD']=='POST'){
 
        $formId = $_POST['formId'];
        $hours = $_POST['hours'];
        $page_name = $_POST['page_name'];
        $price = $_POST['price']; 
        $cost = $_POST['cost']; 
        $city = $_POST['city']; 
         
        $name = $_POST['name'];  
        $email = $_POST['email'];  
        $phone = $_POST['phone'];
        $phone2 = $_POST['phone2'];
        $last_name = $_POST['last_name'];
        $first_name = $_POST['first_name'];
        $middle_name = $_POST['middle_name'];
        $birth_date = $_POST['birth_date'];
        $birth_place = $_POST['birth_place'];
 
        $doc_serial = $_POST['doc_serial'];
        $doc_number = $_POST['doc_number'];
        $issueDate = $_POST['issueDate'];
        $whoIssue = $_POST['whoIssue'];
        $subCode = $_POST['subCode'];
 
        $change_lastName = $_POST['change_lastName'];
        $doc_change_lastName = $_POST['doc_change_lastName'];
 
        $index = $_POST['index'];
        $adress = $_POST['adress'];
        $index2 = $_POST['index2'];
        $adress2 = $_POST['adress2'];
 
        $education = $_POST['education'];
        $institution = $_POST['institution'];
        $graduated = $_POST['graduated'];
        $speciality = $_POST['speciality'];
        $qualification = $_POST['qualification'];
        $diplom = $_POST['diplom'];
        $position = $_POST['position'];
        $start_date = $_POST['start_date'];
 
        $text = $_POST['text'];
    }else{
        $formId = $_GET['formId'];
        $hours = $_GET['hours'];
        $page_name = $_GET['page_name'];
        $price = $_GET['price']; 
        $cost = $_GET['cost']; 
        $city = $_GET['city']; 
         
        $name = $_GET['name'];  
        $email = $_GET['email'];  
        $phone = $_GET['phone'];
        $phone2 = $_GET['phone2'];
        $last_name = $_GET['last_name'];
        $first_name = $_GET['first_name'];
        $middle_name = $_GET['middle_name'];
        $birth_date = $_GET['birth_date'];
        $birth_place = $_GET['birth_place'];
 
        $doc_serial = $_GET['doc_serial'];
        $doc_number = $_GET['doc_number'];
        $issueDate = $_GET['issueDate'];
        $whoIssue = $_GET['whoIssue'];
        $subCode = $_GET['subCode'];
 
        $change_lastName = $_GET['change_lastName'];
        $doc_change_lastName = $_GET['doc_change_lastName'];
 
        $index = $_GET['index'];
        $adress = $_GET['adress'];
        $index2 = $_GET['index2'];
        $adress2 = $_GET['adress2'];
 
        $education = $_GET['education'];
        $institution = $_GET['institution'];
        $graduated = $_GET['graduated'];
        $speciality = $_GET['speciality'];
        $qualification = $_GET['qualification'];
        $diplom = $_GET['diplom'];
        $position = $_GET['position'];
        $start_date = $_GET['start_date'];
 
        $text = $_GET['text'];
    }
 
    $massiv = array(  
        'date_time' => $date_time,
        'name'=>$name, 
        'page_name' => $page_name,
        'price' => $price,
        'cost' => $cost,
        'email'=>$email,  
        'city'=>$city,  
        'text'=>$text,  
        'hours' => $hours, 
        'phone' => $phone,
        'phone2' => $phone2,
        'last_name' => $last_name,
        'first_name' => $first_name,
        'middle_name' => $middle_name,
        'birth_date' => $birth_date,
        'birth_place' => $birth_place,
 
 
        'doc_serial' => $doc_serial,
        'doc_number' => $doc_number,
        'issueDate' => $issueDate,
        'whoIssue' => $whoIssue,
        'subCode' => $subCode,
 
        'change_lastName' => $change_lastName,
        'doc_change_lastName' => $doc_change_lastName,
 
        'index' => $index,
        'adress' => $adress,
        'index2' => $index2,
        'adress2' => $adress2,
 
        'education' => $education,
        'institution' => $institution,
        'graduated' => $graduated,
        'speciality' => $speciality,
        'qualification' => $qualification,
        'diplom' => $diplom,
        'position' => $position,
        'start_date' => $start_date,
 
    );
         
    // file_put_contents($_SERVER['DOCUMENT_ROOT']."/wp-content/data.log", date("d.m.Y H:i:s")."\n".print_r($_SERVER,true)."\n".print_r($massiv,true)."\n============================\n", FILE_APPEND);
 
    $wpdb->insert('wp_wpcreviews',$massiv);  
 
 
    // $recepient = 'sispp_nsk@mail.ru';
    $recepient = 'anatoliykizo@gmail.com';
    // $recepient = 'antony-home@ya.ru';
    $sitename = 'sispp.ru';
     
    $headers  = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=utf-8' . "\r\n";
 
    $arr = $wpdb->insert_id;
 
    echo json_encode($arr);

    if($arr > 0){
        switch ($formId) {
            case 'get_course':
                $pagetitle = "Заказ темы";
                $message = "Тема сообщения: заказ темы <br>\nКонтактное лицо: $name <br>\nТелефон: $phone <br>\nEmail: $email <br>\nДополнительная информация: $text";
                break;
     
            case 'preorder':
                $pagetitle = "Заказ обучающего курса";
                $message = "Курс: $page_name <br>\nЗаказчик: $name <br>\nГород: $city <br>\nТелефон: $phone <br>\nEmail: $email <br>\nДополнительная информация: $text";
                break;
     
            case 'statement':
                $dnum=$arr;
                if ($dnum > 2807) {
                    $dnum = "СФ-" . str_pad(($dnum - 2807), 5, "0", STR_PAD_LEFT);
                } else {
                    $dnum = "С-$dnum";
                }
                $wpdb->update('wp_wpcreviews', array( 'orderID' => $dnum ), array( 'ID' => $arr ));
                   
                $pagetitleForClient = "SISPP.RU $dnum";
                $mesForClient = "<b>Уважаемый (ая) $last_name $first_name $middle_name</b><br>\n
                                <b>Ваша заявка принята.</b><br>\n
                                <b>Мы рады, что Вы выбрали нас и рады сотрудничеству с Вами.</b><br>\n<br>\n
                                Для поступления Вам необходимо распечатать <b>заявление</b> на поступление, <b>договор</b> на оказание
                                образовательных услуг, <b>квитанцию</b> на оплату образовательных услуг, затем <b>подписать и прислать</b>
                                на наш адрес электронной почты <b>sispp_nsk@mail.ru скан-копии</b> следующих документов:<br><br>\n\n
                                - заявление;<br>\n
                                - договор<br>\n
                                - паспорт 2, 3, 5 стр.;<br>\n
                                - документ об образовании;<br>\n
                                - документ о смене ФИО (при несовпадении фамилии в паспорте и документе об образовании).<br><br>\n\n
                                Оплатить квитанцию Вы можете в любом отделении Сбербанка или иного банка.<br><br>\n\n
                                <b>Обращаем Ваше внимание, для быстрого и верного зачисления платежа рекомендуем поле
                                \"Назначение (наименование) платежа\" заполнять в формулировке, прописанной в квитанции.</b><br>\n
                                <p>Доступ Вам будет предоставлен в течении 4-5 рабочих дней с момента поступления оплаты на расчетный счёт ЧУДПО СИПППиСР</p><br>\n
                                <p>Вы можете прямо сейчас открыть и распечатать:</p><br>\n
                                - <a href=\"http://sispp.ru/toprint/statement.php?info=$arr\">Заявление на поступление</a><br>\n
                                - <a href=\"http://sispp.ru/toprint/contract.php?info=$arr\">Договор на обучение</a><br>\n
                                - <a href=\"http://sispp.ru/toprint/receipt.php?info=$arr\">Квитанция на оплату</a><br><br>\n\n
                                Вы можете обращаться к нам по любым вопросам, связанным с обучением!<br><br>\n\n
                                <b>Комплектование пакета документов для обучения, информация о поступлении оплаты:</b><br>\n
                                специалист по методической работе, Ольга Леонидовна<br>\n
                                <b>Сопровождение обучения (сроки и порядок обучения, предоставления итоговых аттестационных работ, доступ к образовательным программам,
                                документов об образовании):</b><br>\n
                                специалист по методической работе, Ольга Андреевна<br><br>\n\n
                                <b>С предложениями и пожеланиями Вы можете обращаться:</b><br>\n
                                руководитель отдела по методической работе, Наталья Анатольевна<br><br>\n\n
                                <b>Успехов в учебе!</b><br><br>\n\n
                                <b>С уважением, коллектив ЧУДПО СИПППиСР<br>\n
                                8 (383) 202-21-81, 8-983-324-1243<br>\n
                                sispp_nsk@mail.ru<br>\n
                                <a href=\"http://www.sispp.ru\">www.sispp.ru</a></b>";
                wp_mail($email, $pagetitleForClient, $mesForClient, $headers);
     
                $pagetitle = "SISPP.RU $dnum";
                $message = "К вам пришла заявка с сайта sispp.ru от $last_name $first_name $middle_name, телефон $phone, адрес электронной почты $email на обучение по программе $page_name \n
                            К заказу прилагаются следующие документы: \n
                            <li> <a href=\"http://sispp.ru/toprint/statement.php?info=$arr\" target=\"_blank\">Заявление на поступление</a>\n
                            <li> <a href=\"http://sispp.ru/toprint/contract.php?info=$arr\" target=\"_blank\">Договор на обучение</a> \n
                            <li> <a href=\"http://sispp.ru/toprint/receipt.php?info=$arr\" target=\"_blank\">Квитанция на оплату обучения</a> \n
                            <li> <a href=\"http://sispp.ru/toprint/act.php?info=$arr\" target=\"_blank\">Акт выполненных работ</a>";
                break;
     
            default:
                    $pagetitle = "Сообщение с сайта SISPP.RU";
                    $message = "Контактное лицо: $name <br>\nТелефон: $phone <br>\nEmail: $email <br>\nДополнительная информация: $text";
                break;
        }
        wp_mail($recepient, $pagetitle, $message, $headers);
    }
}  


class WPCustomerReviews {

    var $dbtable = 'wpcreviews';
    var $force_active_page = false;
    var $got_aggregate = false;
    var $options = array();
    var $p = '';
    var $page = 1;

    function WPCustomerReviews() {
        global $wpdb;

        define('IN_WPCR', 1);
        
        /* uncomment the below block to display strict/notice errors */
        /*
        restore_error_handler();
        error_reporting(E_ALL);
        ini_set('error_reporting', E_ALL);
        ini_set('html_errors',TRUE);
        ini_set('display_errors',TRUE);
        */

        $this->dbtable = $wpdb->prefix . $this->dbtable;

        // add_action('the_content', array(&$this, 'do_the_content'), 10); /* prio 10 prevents a conflict with some odd themes */
        add_action('init', array(&$this, 'init')); /* init also tries to insert script/styles */
        add_action('admin_init', array(&$this, 'admin_init'));
        
        add_action('template_redirect',array(&$this, 'template_redirect')); /* handle redirects and form posts, and add style/script if needed */
        
        add_action('admin_menu', array(&$this, 'addmenu'));
        add_action('wp_ajax_update_field', array(&$this, 'admin_view_reviews')); /* special ajax stuff */
        add_action('save_post', array(&$this, 'admin_save_post'), 10, 2); /* 2 arguments */
        
        add_filter('plugin_action_links_' . plugin_basename(__FILE__), array(&$this, 'plugin_settings_link'));
    }
	
    /* keep out of admin file */
    function plugin_settings_link($links) {
        $url = get_admin_url().'options-general.php?page=wpcr_options';
        $settings_link = '<a href="'.$url.'"><img src="' . $this->getpluginurl() . 'star.png" />&nbsp;Settings</a>';
        array_unshift($links, $settings_link);
        return $links;
    }

    /* keep out of admin file */
    function addmenu() {
        add_options_page('Заявки', '<img src="' . $this->getpluginurl() . 'star.png" />&nbsp;Заявки', 'manage_options', 'wpcr_options', array(&$this, 'admin_options'));
        add_menu_page('Заявки', 'Заявки', 'edit_others_posts', 'wpcr_view_reviews', array(&$this, 'admin_view_reviews'), $this->getpluginurl() . 'star.png', '50.91'); /* try to resolve issues with other plugins */
        global $WPCustomerReviewsAdmin;
        $this->include_admin(); /* include admin functions */
        // $WPCustomerReviewsAdmin->wpcr_add_meta_box();
    }

    /* forward to admin file */
    function admin_options() {
        global $WPCustomerReviewsAdmin;
        $this->include_admin(); /* include admin functions */
        $WPCustomerReviewsAdmin->real_admin_options();
    }

    /* forward to admin file */
    function admin_save_post($post_id, $post) {
        global $WPCustomerReviewsAdmin;
        $this->include_admin(); /* include admin functions */
        $WPCustomerReviewsAdmin->real_admin_save_post($post_id);
    }

    /* forward to admin file */
    function admin_view_reviews() {
        global $WPCustomerReviewsAdmin;
        $this->include_admin(); /* include admin functions */
        $WPCustomerReviewsAdmin->real_admin_view_reviews();
    }
    
    
    function get_jumplink_for_review($review,$page) {
        /* $page will be 1 for shortcode usage since it pulls most recent, which SHOULD all be on page 1 */
        $link = get_permalink( $review->page_id );
        
        if (strpos($link,'?') === false) {
            $link = trailingslashit($link) . "?wpcrp=$page#hreview-$review->id";
        } else {
            $link = $link . "&wpcrp=$page#hreview-$review->id";
        }
        
        return $link;
    }

    function get_options() {
    //     $home_domain = @parse_url(get_home_url());
    //     $home_domain = $home_domain['scheme'] . "://" . $home_domain['host'] . '/';

        $default_options = array(
            'reviews_per_page' => 10,
        );
        
        $this->options = get_option('wpcr_options', $default_options);

    //     /* magically easy migrations to newer versions */
        $has_new = false;
        foreach ($default_options as $col => $def_val) {

            if (!isset($this->options[$col])) {
                $this->options[$col] = $def_val;
                $has_new = true;
            }

            if (is_array($def_val)) {
                foreach ($def_val as $acol => $aval) {
                    if (!isset($this->options[$col][$acol])) {
                        $this->options[$col][$acol] = $aval;
                        $has_new = true;
                    }
                }
            }
        }

        if ($has_new) {
            update_option('wpcr_options', $this->options);
        }
    }

    function make_p_obj() {
        $this->p = new stdClass();

        foreach ($_GET as $c => $val) {
            if (is_array($val)) {
                $this->p->$c = $val;
            } else {
                $this->p->$c = trim(stripslashes($val));
            }
        }

        foreach ($_POST as $c => $val) {
            if (is_array($val)) {
                $this->p->$c = $val;
            } else {
                $this->p->$c = trim(stripslashes($val));
            }
        }
    }

    function is_active_page() {
        global $post;
        
        $has_shortcode = $this->force_active_page;
        if ( $has_shortcode !== false ) {
            return 'shortcode';
        }
        
        if ( !isset($post) || !isset($post->ID) || intval($post->ID) == 0 ) {
            return false; /* we can only use the plugin if we have a valid post ID */
        }
        
        if (!is_singular()) {
            return false; /* not on a single post/page view */
        }
        
        $wpcr_enabled_post = get_post_meta($post->ID, 'wpcr_enable', true);
        if ( $wpcr_enabled_post ) {
            return 'enabled';
        }
        
        return false;
    }
    
    function add_style_script() {
        /* to prevent compatibility issues and for shortcodes, add to every page */
        // wp_enqueue_style('wp-customer-reviews');
		wp_enqueue_script('wp-customer-reviews');
    }
	
	function template_redirect() {
	
		/* do this in template_redirect so we can try to redirect cleanly */
        global $post;
        if (!isset($post) || !isset($post->ID)) {
            $post = new stdClass();
            $post->ID = 0;
        }
        
        if (isset($_COOKIE['wpcr_status_msg'])) {
            $this->status_msg = $_COOKIE['wpcr_status_msg'];
            if ( !headers_sent() ) {
                setcookie('wpcr_status_msg', '', time() - 3600); /* delete the cookie */
                unset($_COOKIE['wpcr_status_msg']);
            }
        }
        
        $GET_P = "submitwpcr_$post->ID";

        if ($post->ID > 0 && isset($this->p->$GET_P) && $this->p->$GET_P == $this->options['submit_button_text'])
        {
            // $msg = $this->add_review($post->ID);
            $has_error = $msg[0];
            $status_msg = $msg[1];
            $url = get_permalink($post->ID);
            $cookie = array('wpcr_status_msg' => $status_msg);
            $this->wpcr_redirect($url, $cookie);
        }
	}
    
    function rand_string($length) {
        $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        $str = '';

        $size = strlen($chars);
        for ($i = 0; $i < $length; $i++) {
            $str .= $chars[rand(0, $size - 1)];
        }

        return $str;
    }

    function get_aggregate_reviews($pageID) {
        if ($this->got_aggregate !== false) {
            return $this->got_aggregate;
        }

        global $wpdb;

        $pageID = intval($pageID);
        $row = $wpdb->get_results("SELECT COUNT(*) AS `total`,AVG(review_rating) AS `aggregate_rating`,MAX(review_rating) AS `max_rating` FROM `$this->dbtable` WHERE `page_id`=$pageID AND `status`=1");

        /* make sure we have at least one review before continuing below */
        if ($wpdb->num_rows == 0 || $row[0]->total == 0) {
            $this->got_aggregate = array("aggregate" => 0, "max" => 0, "total" => 0, "text" => 'Reviews for my site');
            return false;
        }

        $aggregate_rating = $row[0]->aggregate_rating;
        $max_rating = $row[0]->max_rating;
        $total_reviews = $row[0]->total;

        $row = $wpdb->get_results("SELECT `text` FROM `$this->dbtable` WHERE `page_id`=$pageID AND `status`=1 ORDER BY `date_time` DESC LIMIT 1");
        $sample_text = substr($row[0]->text, 0, 180);

        $this->got_aggregate = array("aggregate" => $aggregate_rating, "max" => $max_rating, "total" => $total_reviews, "text" => $sample_text);
        return true;
    }

    function get_reviews($postID, $startpage, $perpage, $status) {
        global $wpdb;

        $startpage = $startpage - 1; /* mysql starts at 0 instead of 1, so reduce them all by 1 */
        if ($startpage < 0) { $startpage = 0; }

        $limit = 'LIMIT ' . $startpage * $perpage . ',' . $perpage;

        if ($status == -1) {
            $qry_status = '1=1';
        } else {
            $qry_status = "`status`=$status";
        }

        $postID = intval($postID);
        if ($postID == -1) {
            $and_post = '';
        } else {
            $and_post = "AND `page_id`=$postID";
        }

        $reviews = $wpdb->get_results("SELECT 
            `id`,
            `date_time`,
            `name`,
            `email`,
            `text`,
            `status`,
            `page_name`,
            `price`,
            `cost`,
            `phone`,
    	    `city`,
            `hours`,
            `phone2`,
            `last_name`,
            `first_name`,
            `middle_name`,
            `birth_date`,
            `birth_place`,
            `doc_serial`,
            `doc_number`,
            `issueDate`,
            `whoIssue`,
            `subCode`,
            `change_lastName`,
            `doc_change_lastName`,
            `index`,
            `adress`,
            `index2`,
            `adress2`,
            `education`,
            `institution`,
            `graduated`,
            `speciality`,
            `qualification`,
            `diplom`,
            `position`,
            `start_date`

            FROM `$this->dbtable` WHERE $qry_status $and_post ORDER BY `date_time` DESC $limit
            ");

        $total_reviews = $wpdb->get_results("SELECT COUNT(*) AS `total` FROM `$this->dbtable` WHERE $qry_status $and_post");
        $total_reviews = $total_reviews[0]->total;

        return array($reviews, $total_reviews);
    }


    function iso8601($time=false) {
        if ($time === false)
            $time = time();
        $date = date('Y-m-d\TH:i:sO', $time);
        return (substr($date, 0, strlen($date) - 2) . ':' . substr($date, -2));
    }

    function pagination($total_results, $reviews_per_page) {
        global $post; /* will exist if on a post */

        $out = '';
        $uri = false;
        $pretty = false;

        $range = 2;
        $showitems = ($range * 2) + 1;

        $paged = $this->page;
        if ($paged == 0) { $paged = 1; }
        
        if (!isset($this->p->review_status)) { $this->p->review_status = 0; }

        $pages = ceil($total_results / $reviews_per_page);

        if ($pages > 1) {
            if (is_admin()) {
                $url = '?page=wpcr_view_reviews&amp;review_status=' . $this->p->review_status . '&amp;';
            } else {
                $uri = trailingslashit(get_permalink($post->ID));
                if (strpos($uri, '?') === false) {
                    $url = $uri . '?';
                    $pretty = true;
                } /* page is using pretty permalinks */ else {
                    $url = $uri . '&amp;';
                    $pretty = false;
                } /* page is using get variables for pageid */
            }

            $out .= '<div id="wpcr_pagination"><div id="wpcr_pagination_page">Page: </div>';

            if ($paged > 2 && $paged > $range + 1 && $showitems < $pages) {
                if ($uri && $pretty) {
                    $url2 = $uri;
                } /* not in admin AND using pretty permalinks */ else {
                    $url2 = $url;
                }
                $out .= '<a href="' . $url2 . '">&laquo;</a>';
            }

            if ($paged > 1 && $showitems < $pages) {
                $out .= '<a href="' . $url . 'wpcrp=' . ($paged - 1) . '">&lsaquo;</a>';
            }

            for ($i = 1; $i <= $pages; $i++) {
                if ($i == $paged) {
                    $out .= '<span class="wpcr_current">' . $paged . '</span>';
                } else if (!($i >= $paged + $range + 1 || $i <= $paged - $range - 1) || $pages <= $showitems) {
                    if ($i == 1) {
                        if ($uri && $pretty) {
                            $url2 = $uri;
                        } /* not in admin AND using pretty permalinks */ else {
                            $url2 = $url;
                        }
                        $out .= '<a href="' . $url2 . '" class="wpcr_inactive">' . $i . '</a>';
                    } else {
                        $out .= '<a href="' . $url . 'wpcrp=' . $i . '" class="wpcr_inactive">' . $i . '</a>';
                    }
                }
            }

            if ($paged < $pages && $showitems < $pages) {
                $out .= '<a href="' . $url . 'wpcrp=' . ($paged + 1) . '">&rsaquo;</a>';
            }
            if ($paged < $pages - 1 && $paged + $range - 1 < $pages && $showitems < $pages) {
                $out .= '<a href="' . $url . 'wpcrp=' . $pages . '">&raquo;</a>';
            }
            $out .= '</div>';
            $out .= '<div class="wpcr_clear wpcr_pb5"></div>';

            return $out;
        }
    }
   
    
    /* trims text, but does not break up a word */
    function trim_text_to_word($text,$len) {
        if(strlen($text) > $len) {
          $matches = array();
          preg_match("/^(.{1,$len})[\s]/i", $text, $matches);
          $text = $matches[0];
        }
        return $text.'... ';
    }

    function deactivate() {
        /* do not fire on upgrading plugin or upgrading WP - only on true manual deactivation */
        if (isset($this->p->action) && $this->p->action == 'deactivate') {
            $this->options['activate'] = 0;
            update_option('wpcr_options', $this->options);
            global $WPCustomerReviewsAdmin;
            $this->include_admin(); /* include admin functions */
            $WPCustomerReviewsAdmin->notify_activate(2);
        }
    }

    function wpcr_redirect($url, $cookie = array()) {
        
        $headers_sent = headers_sent();
        
        if ($headers_sent == true) {
            /* use JS redirect and add cookie before redirect */
            /* we do not html comment script blocks here - to prevent any issues with other plugins adding content to newlines, etc */
            $out = "<html><head><title>Redirecting...</title></head><body><div style='clear:both;text-align:center;padding:10px;'>" .
                    "Processing... Please wait..." .
                    "<script type='text/javascript'>";
            foreach ($cookie as $col => $val) {
                $val = preg_replace("/\r?\n/", "\\n", addslashes($val));
                $out .= "document.cookie=\"$col=$val\";";
            }
            $out .= "window.location='$url';";
            $out .= "</script>";
            $out .= "</div></body></html>";
            echo $out;
        } else {
            foreach ($cookie as $col => $val) {
                setcookie($col, $val); /* add cookie via headers */
            }
            ob_end_clean();
            wp_redirect($url); /* nice redirect */
        }
        
        exit();
    }

    function init() { /* used for admin_init also */
        $this->make_p_obj(); /* make P variables object */
        $this->get_options(); /* populate the options array */
        // $this->check_migrate(); /* call on every instance to see if we have upgraded in any way */

        if ( !isset($this->p->wpcrp) ) { $this->p->wpcrp = 1; }
        
        $this->page = intval($this->p->wpcrp);
        if ($this->page < 1) { $this->page = 1; }
        
        add_shortcode( 'WPCR_INSERT', array(&$this, 'shortcode_wpcr_insert') );
        add_shortcode( 'WPCR_SHOW', array(&$this, 'shortcode_wpcr_show') );
        
        // wp_register_style('wp-customer-reviews', $this->getpluginurl() . 'wp-customer-reviews.css', array(), $this->plugin_version);
        // wp_register_script('wp-customer-reviews', $this->getpluginurl() . 'wp-customer-reviews.js', array('jquery'), $this->plugin_version);
		/* add style and script here if needed for some theme compatibility */
		$this->add_style_script();
    }
    
    function shortcode_wpcr_insert() {
        $this->force_active_page = 1;
        return $this->do_the_content('shortcode_insert');        
    }
    
    function shortcode_wpcr_show($atts) {
        $this->force_active_page = 1;
        
        extract( shortcode_atts( array('postid' => 'all','num' => '3','hidecustom' => '0','hideresponse' => '0', 'snippet' => '0','more' => ''), $atts ) );
        
        if (strtolower($postid) == 'all') { $postid = -1; /* -1 queries all reviews */ }
        $postid = intval($postid);
        $num = intval($num);
        $hidecustom = intval($hidecustom);
        $hideresponse = intval($hideresponse);
        $snippet = intval($snippet);
        $more = $more;
        
        if ($postid < -1) { $postid = -1; }
        if ($num < 1) { $num = 3; }
        if ($hidecustom < 0 || $hidecustom > 1) { $hidecustom = 0; }
        if ($hideresponse < 0 || $hideresponse > 1) { $hideresponse = 0; } 
        if ($snippet < 0) { $snippet = 0; }
        
        $inside_div = false;
        
        $ret_Arr = $this->output_reviews_show( $inside_div, $postid, $num, $num, $hidecustom, $hideresponse, $snippet, $more );
        return $ret_Arr[0];
    }

    function activate() {
        register_setting('wpcr_gotosettings', 'wpcr_gotosettings');
        add_option('wpcr_gotosettings', true); /* used for redirecting to settings page upon initial activation */
    }

    function include_admin() {
        global $WPCustomerReviewsAdmin;
        require_once($this->getplugindir() . 'wp-customer-reviews-admin.php'); /* include admin functions */
    }

    function admin_init() {
        global $WPCustomerReviewsAdmin;
        $this->include_admin(); /* include admin functions */
        $WPCustomerReviewsAdmin->real_admin_init();
    }

    function getpluginurl() {
        return trailingslashit(plugins_url(basename(dirname(__FILE__))));
    }

    function getplugindir() {
        return trailingslashit(WP_PLUGIN_DIR . '/' . str_replace(basename(__FILE__), "", plugin_basename(__FILE__)));
    }

}

if (!defined('IN_WPCR')) {
    global $WPCustomerReviews;
    $WPCustomerReviews = new WPCustomerReviews();
    register_activation_hook(__FILE__, array(&$WPCustomerReviews, 'activate'));
    register_deactivation_hook(__FILE__, array(&$WPCustomerReviews, 'deactivate'));
}
?>