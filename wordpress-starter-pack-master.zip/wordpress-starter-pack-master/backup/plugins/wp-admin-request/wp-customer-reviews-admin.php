<?php
class WPCustomerReviewsAdmin
{
	var $parentClass = '';

	function WPCustomerReviewsAdmin($parentClass) {
            define('IN_WPCR_ADMIN',1);

            /* begin - haxish but it works */
            $this->parentClass = &$parentClass;
            foreach ($this->parentClass as $col => $val) {
                $this->$col = &$this->parentClass->$col;
            }
            /* end - haxish but it works */
	}
	
	function real_admin_init() {
		$this->parentClass->init();
		// $this->enqueue_admin_stuff();
		
		register_setting( 'wpcr_options', 'wpcr_options' );

		/* used for redirecting to settings page upon initial activation */
		if (get_option('wpcr_gotosettings', false)) {
			delete_option('wpcr_gotosettings');
			unregister_setting('wpcr_gotosettings', 'wpcr_gotosettings');

			/* no auto settings redirect if upgrading */
			if ( isset($this->p->action) && $this->p->action == 'activate-plugin' ) { return false; }

			$url = get_admin_url().'options-general.php?page=wpcr_options';
			$this->parentClass->wpcr_redirect($url);
		}
		
	}
	
	
	function real_admin_save_post($post_id) {
            global $meta_box,$wpdb;

            // check autosave
            if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
                return $post_id;
            }

            // check permissions
            if ( isset($this->p->post_type) && $this->p->post_type == 'page' ) {
                if (!current_user_can('edit_page', $post_id)) {
                    return $post_id;
                }
            } elseif (!current_user_can('edit_post', $post_id)) {
                return $post_id;
            }

			if ( isset($meta_box) && isset($meta_box['fields']) && is_array($meta_box['fields']) )
			{
				foreach ($meta_box['fields'] as $field) {
					
					if ( isset($this->p->post_title) ) {
						$old = get_post_meta($post_id, $field['id'], true);
						
						if (isset($this->p->$field['id'])) {
							$new = $this->p->$field['id'];
							if ($new && $new != $old) {
								update_post_meta($post_id, $field['id'], $new);
							} elseif ($new == '' && $old) {
								delete_post_meta($post_id, $field['id'], $old);
							}
						} else {
							delete_post_meta($post_id, $field['id'], $old);
						}
					}
					
				}
			}

            return $post_id;
	}
	
	function wpcr_show_meta_box() {
		global $meta_box, $post;
		
		echo '<table class="form-table">';

		foreach ($meta_box['fields'] as $field) {
			// get current post meta data
			$meta = get_post_meta($post->ID, $field['id'], true);
                                               
			if ($field['id'] == 'wpcr_enable' && $post->post_name == '') {
				if ($post->post_type == 'post' && $this->options['enable_posts_default'] == 1) {
					$meta = 1; /* enable by default for posts */
				}
				else if ($post->post_type == 'page' && $this->options['enable_pages_default'] == 1) {
					$meta = 1; /* enable by default for pages */
				}
			}
			
			echo '<tr>',
				 '<th style="width:30%"><label for="', $field['id'], '">', $field['name'], '</label></th>',
				 '<td>';
			switch ($field['type']) {
				case 'text':
					echo '<input type="text" name="', $field['id'], '" id="', $field['id'], '" value="', $meta ? $meta : $field['std'], '" size="30" style="width:97%" />', '<br />', $field['desc'];
					break;
				case 'textarea':
					echo '<textarea name="', $field['id'], '" id="', $field['id'], '" cols="60" rows="4" style="width:97%">', $meta ? $meta : $field['std'], '</textarea>', '<br />', $field['desc'];
					break;
				case 'select':
					echo '<select name="', $field['id'], '" id="', $field['id'], '">';
					foreach ($field['options'] as $option) {
						echo '<option', $meta == $option ? ' selected="selected"' : '', '>', $option, '</option>';
					}
					echo '</select>';
					break;
				case 'radio':
					foreach ($field['options'] as $option) {
						echo '<input type="radio" name="', $field['id'], '" value="', $option['value'], '"', $meta == $option['value'] ? ' checked="checked"' : '', ' />', $option['name'];
					}
					break;
				case 'checkbox':
					echo '<input value="1" type="checkbox" name="', $field['id'], '" id="', $field['id'], '"', $meta ? ' checked="checked"' : '', ' />';
					break;
			}
			echo '<td></tr>';
		}
		
		echo '</table>';
	}
	
	function createUpdateReviewTable() {
            require_once( ABSPATH . '/wp-admin/includes/upgrade.php' );
            
            $sql = "CREATE TABLE $this->dbtable (
                      id int(11) NOT NULL AUTO_INCREMENT,
                      date_time datetime NOT NULL,
                      name varchar(150) DEFAULT NULL,
                      email varchar(150) DEFAULT NULL,
                      text text,
                      status tinyint(1) DEFAULT '0',
                      PRIMARY KEY (id),
                      KEY status (status)
                      )";
            
            dbDelta($sql);
        }
	
	function force_update_cache() {
			return; /* testing to increase performance */
			global $wpdb;
				
			/* update all pages, since some may have just disabled the plugin */
			$pages = $wpdb->get_results( "SELECT `ID` FROM $wpdb->posts AS `p`" );
			foreach ($pages as $page) {
                $post = get_post($page->ID);
				if ($post) {
					clean_post_cache($page->ID);
					wp_update_post($post); /* comment to prevent some plugins from firing tweets/etc when updating, can have side effects */
                }
            }
    }

	/* some admin styles can override normal styles for inplace edits */
	// function enqueue_admin_stuff() {
 //            $pluginurl = $this->parentClass->getpluginurl();

 //            if (isset($this->p->page) && ( $this->p->page == 'wpcr_view_reviews' || $this->p->page == 'wpcr_options' ) ) {
 //                wp_register_script('wp-customer-reviews-admin',$pluginurl.'wp-customer-reviews-admin.js',array('jquery'),$this->plugin_version);
	// 			wp_register_style('wp-customer-reviews-admin',$pluginurl.'wp-customer-reviews-admin.css',array(),$this->plugin_version);  
	// 			wp_enqueue_script('wp-customer-reviews-admin');
	// 			wp_enqueue_style('wp-customer-reviews-admin');
 //            }
	// }

	    function update_options() {
        /* we still process and validate this internally, instead of using the Settings API */
        
        global $wpdb;
        $msg ='';
        
        $this->security();
                
        if (isset($this->p->optin))
        {      			
            if ($this->options['activate'] == 0)
            {
                $this->options['activate'] = 1;
                $this->options['act_email'] = $this->p->email;

                update_option('wpcr_options', $this->options);
                $this->notify_activate(1);
                $msg = 'Thank you. Please configure the plugin below.';
            }
        }
        else
        {
            check_admin_referer('wpcr_options-options'); /* nonce check */
            
            $updated_options = $this->options;
		
            /* reset these to 0 so we can grab the settings below */
            $updated_options['ask_fields']['fname'] = 0;
            $updated_options['ask_fields']['femail'] = 0;
            $updated_options['ask_fields']['fwebsite'] = 0;
            $updated_options['ask_fields']['ftitle'] = 0;
            $updated_options['require_fields']['fname'] = 0;
            $updated_options['require_fields']['femail'] = 0;
            $updated_options['require_fields']['fwebsite'] = 0;
            $updated_options['require_fields']['ftitle'] = 0;
            $updated_options['show_fields']['fname'] = 0;
            $updated_options['show_fields']['femail'] = 0;
            $updated_options['show_fields']['fwebsite'] = 0;
            $updated_options['show_fields']['ftitle'] = 0;
            $updated_options['ask_custom'] = array();
            $updated_options['field_custom'] = array();
            $updated_options['require_custom'] = array();
            $updated_options['show_custom'] = array();
		
            /* quick update of all options needed */
            foreach ($this->p as $col => $val)
            {
                if (isset($this->options[$col]))
                {
                    switch($col)
                    {
                        case 'field_custom': /* we should always hit field_custom before ask_custom, etc */
                            foreach ($val as $i => $name) { $updated_options[$col][$i] = ucwords( strtolower( $name ) ); } /* we are so special */
                            break;
                        case 'ask_custom':
                        case 'require_custom':
                        case 'show_custom':
                            foreach ($val as $i => $v) { $updated_options[$col][$i] = 1; } /* checkbox array with ints */
                            break;
                        case 'ask_fields':
                        case 'require_fields':
                        case 'show_fields':
                            foreach ($val as $v) { $updated_options[$col]["$v"] = 1; } /* checkbox array with names */
                            break;
                        default:
                            $updated_options[$col] = $val; /* a non-array normal field */
                            break;
                    }
                }
            }
            
            /* prevent E_NOTICE warnings */
            if (!isset($this->p->enable_pages_default)) { $this->p->enable_pages_default = 0; }
            if (!isset($this->p->enable_posts_default)) { $this->p->enable_posts_default = 0; }
            if (!isset($this->p->goto_show_button)) { $this->p->goto_show_button = 0; }
            if (!isset($this->p->support_us)) { $this->p->support_us = 0; }
            
            /* some int validation */
            $updated_options['enable_pages_default'] = intval($this->p->enable_pages_default);
            $updated_options['enable_posts_default'] = intval($this->p->enable_posts_default);
            $updated_options['form_location'] = intval($this->p->form_location);
            $updated_options['goto_show_button'] = intval($this->p->goto_show_button);
            $updated_options['reviews_per_page'] = intval($this->p->reviews_per_page);
            $updated_options['show_hcard'] = intval($this->p->show_hcard);
            $updated_options['show_hcard_on'] = intval($this->p->show_hcard_on);
            $updated_options['support_us'] = intval($this->p->support_us);
            
            if ($updated_options['reviews_per_page'] < 1) { $updated_options['reviews_per_page'] = 10; }

            if ($updated_options['show_hcard_on']) {
                if (
                    empty($updated_options['business_name']) ||
                    empty($updated_options['business_url']) ||
                    empty($updated_options['business_email']) ||
                    empty($updated_options['business_street']) ||
                    empty($updated_options['business_city']) ||
                    empty($updated_options['business_state']) ||
                    empty($updated_options['business_zip']) ||
                    empty($updated_options['business_phone'])
                ) {
                    $msg .= "* Notice: You must enter in ALL business information to use the hCard output *<br /><br />";
                    $updated_options['show_hcard_on'] = 0;
                }
            }
			
            $msg .= 'Your settings have been saved.';
            update_option('wpcr_options', $updated_options);
            $this->force_update_cache(); /* update any caches */
        }

        return $msg;
    }
	
	/* v4 uuid */
	function gen_uuid() {
            return sprintf( '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
                mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ),
                mt_rand( 0, 0xffff ),
                mt_rand( 0, 0x0fff ) | 0x4000,
                mt_rand( 0, 0x3fff ) | 0x8000,
                mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff )
            );
	}
	
   
	
    function my_get_pages() { /* gets pages, even if hidden using a plugin */
        global $wpdb;
        
        $res = $wpdb->get_results("SELECT `ID`,`post_title` FROM `$wpdb->posts` WHERE `post_status` = 'publish' AND `post_type` = 'page' ORDER BY `ID`");
        return $res;
    }
	
    function show_options() {
        
        echo '
        <div class="postbox" style="width:700px;">
            <h3>Display Options</h3>
            
                <form method="post" action="">


                    <div style="background:#eaf2fa;padding:6px;border-top:1px solid #ccc;border-bottom:1px solid #ccc;">
                        <legend>Review Page Settings</legend>
                    </div>
                    <div style="padding:10px;padding-bottom:10px;">
                        <span style="color:#BE5409;">You can use this plugin on multiple pages/posts. You will find a "WP Customer Reviews" settings box when editing any page/post.</span>
                        <br /><br />
                        <label for="reviews_per_page">Reviews shown per page: </label><input style="width:40px;" type="text" id="reviews_per_page" name="reviews_per_page" value="'.$this->options['reviews_per_page'].'" />
                        <br /><br />
                        <div class="submit" style="padding:10px 0px 0px 0px;"><input type="submit" class="button-primary" value="Save Changes" name="Submit"></div>
                    </div>';
                    settings_fields("wpcr_options");
                    echo '
                </form>
                <br />
            </div>
        </div>';
        /* settings_fields is for Settings API / WPMU / future WP compatibility */
    }
    
    function security() {
        if (!current_user_can('manage_options'))
        {
            wp_die( __('You do not have sufficient permissions to access this page.') );
        }
    }
	
    function real_admin_options() {
        $this->security();

        $msg = '';
		
		// make sure the db is created
		global $wpdb;
		$exists = $wpdb->get_var("SHOW TABLES LIKE '$this->dbtable'");
		if ($exists != $this->dbtable) {
			$this->parentClass->check_migrate(true);
			$exists = $wpdb->get_var("SHOW TABLES LIKE '$this->dbtable'");
			if ($exists != $this->dbtable) {
				print "<br /><br /><br />COULD NOT CREATE DATABASE TABLE, PLEASE REPORT THIS ERROR";
			}
		}
        
        if (!isset($this->p->Submit)) { $this->p->Submit = ''; }
        
        if ($this->p->Submit == 'Save Changes') {
            $msg = $this->update_options();
            $this->parentClass->get_options();
        }
        elseif ($this->p->Submit == 'Enable Plugin for all Existing Posts') {
            global $wpdb;
            $wpdb->query( "DELETE $wpdb->postmeta FROM $wpdb->postmeta
                            LEFT JOIN $wpdb->posts ON $wpdb->posts.ID = $wpdb->postmeta.post_id 
                            WHERE $wpdb->posts.post_type = 'post' AND $wpdb->postmeta.meta_key = 'wpcr_enable' " );
            
            $wpdb->query( "INSERT INTO $wpdb->postmeta 
                            SELECT 0,$wpdb->posts.ID,'wpcr_enable',1
                            FROM $wpdb->posts
                            WHERE $wpdb->posts.post_type = 'post' " ); 
        }
        elseif ($this->p->Submit == 'Disable Plugin for all Existing Posts') {
            global $wpdb;
            $wpdb->query( "DELETE $wpdb->postmeta FROM $wpdb->postmeta
                            LEFT JOIN $wpdb->posts ON $wpdb->posts.ID = $wpdb->postmeta.post_id 
                            WHERE $wpdb->posts.post_type = 'post' AND $wpdb->postmeta.meta_key = 'wpcr_enable' " );
        }
        elseif ($this->p->Submit == 'Enable Plugin for all Existing Pages') {
            global $wpdb;
            $wpdb->query( "DELETE $wpdb->postmeta FROM $wpdb->postmeta
                            LEFT JOIN $wpdb->posts ON $wpdb->posts.ID = $wpdb->postmeta.post_id 
                            WHERE $wpdb->posts.post_type = 'page' AND $wpdb->postmeta.meta_key = 'wpcr_enable' " );
            
            $wpdb->query( "INSERT INTO $wpdb->postmeta 
                            SELECT 0,$wpdb->posts.ID,'wpcr_enable',1
                            FROM $wpdb->posts
                            WHERE $wpdb->posts.post_type = 'page' " );                 
        }
        elseif ($this->p->Submit == 'Disable Plugin for all Existing Pages') {
            global $wpdb;
            $wpdb->query( "DELETE $wpdb->postmeta FROM $wpdb->postmeta
                            LEFT JOIN $wpdb->posts ON $wpdb->posts.ID = $wpdb->postmeta.post_id 
                            WHERE $wpdb->posts.post_type = 'page' AND $wpdb->postmeta.meta_key = 'wpcr_enable' " );
        }
        
        if (isset($this->p->email)) {
            $msg = $this->update_options();
            $this->parentClass->get_options();
        }
        
        echo '
        <div id="wpcr_respond_1" class="wrap">
            <h2>WP Customer Reviews - Options</h2>';
            if ($msg) { echo '<h3 style="color:#a00;">'.$msg.'</h3>'; }

        $this->show_options();
        echo '<br /></div>';
    }
	
    function real_admin_view_reviews() {      
        global $wpdb;
        
        if (!isset($this->p->s)) { $this->p->s = ''; }
        $this->p->s_orig = $this->p->s;
        
        if (!isset($this->p->review_status)) { $this->p->review_status = 0; }
        $this->p->review_status = intval($this->p->review_status);
        
        /* begin - actions */
        if (isset($this->p->action)) {
		
            if (isset($this->p->r)) {
                $this->p->r = intval($this->p->r);

                switch ($this->p->action) {
                    case 'deletereview':
                        $wpdb->query("DELETE FROM `$this->dbtable` WHERE `id`={$this->p->r} LIMIT 1");
                        break;
                    case 'trashreview':
                        $wpdb->query("UPDATE `$this->dbtable` SET `status`=2 WHERE `id`={$this->p->r} LIMIT 1");
                        break;
                    case 'approvereview':
                        $wpdb->query("UPDATE `$this->dbtable` SET `status`=1 WHERE `id`={$this->p->r} LIMIT 1");
                        break;
                    case 'unapprovereview':
                        $wpdb->query("UPDATE `$this->dbtable` SET `status`=0 WHERE `id`={$this->p->r} LIMIT 1");
                        break;
                    case 'update_field':
                        
                        ob_end_clean();
                        
                        if (!is_array($this->p->json)) {
                            header('HTTP/1.1 403 Forbidden');
                            echo json_encode(array("errors" => 'Bad Request'));
                            exit(); 
                        }
                        
                        $show_val = '';
                        $update_col = false;
                        $update_val = false;
                        
                        foreach ($this->p->json as $col => $val) {
                            
                            switch ($col) {
                                case 'date_time':
                                    $d = date("m/d/Y g:i a",strtotime($val));
                                    if (!$d || $d == '01/01/1970 12:00 am') {
                                        header('HTTP/1.1 403 Forbidden');
                                        echo json_encode(array("errors" => 'Bad Date Format'));
                                        exit(); 
                                    }
                                    
                                    $show_val = $d;
                                    $d2 = date("Y-m-d H:i:s",strtotime($val));
                                    $update_col = mysql_real_escape_string($col);
                                    $update_val = mysql_real_escape_string($d2);
                                    break;
                                    
                                default:
                                    if ($val == '') {
                                        header('HTTP/1.1 403 Forbidden');
                                        echo json_encode(array("errors" => 'Bad Value'));
                                        exit(); 
                                    }
									
                                    /* for storing in DB - fix with IE 8 workaround */
                                    $val = str_replace( array("<br />","<br/>","<br>") , "\n" , $val );	

                                    if (substr($col,0,7) == 'custom_') /* updating custom fields */
                                    {
                                        $custom_fields = array(); /* used for insert as well */
                                        $custom_count = count($this->options['field_custom']); /* used for insert as well */
                                        for ($i = 0; $i < $custom_count; $i++)
                                        {
                                            $custom_fields[$i] = $this->options['field_custom'][$i];
                                        }

                                        $custom_num = substr($col,7); /* gets the number after the _ */
                                        /* get the old custom value */
                                        $old_value = $wpdb->get_results("SELECT `custom_fields` FROM `$this->dbtable` WHERE `id`={$this->p->r} LIMIT 1");										
                                        if ($old_value && $wpdb->num_rows)
                                        {
                                            $old_value = @unserialize($old_value[0]->custom_fields);
                                            if (!is_array($old_value)) { $old_value = array(); }
                                            $custom_name = $custom_fields[$custom_num];
                                            $old_value[$custom_name] = $val;
                                            $new_value = serialize($old_value);											
                                            $update_col = mysql_real_escape_string('custom_fields');
                                            $update_val = mysql_real_escape_string($new_value);
                                        }
                                    }
                                    else /* updating regular fields */
                                    {									
                                        $update_col = mysql_real_escape_string($col);
                                        $update_val = mysql_real_escape_string($val);
                                    }

                                    $show_val = $val;
                                    
                                    break;
                            }
                            
                        }
                        
                        if ($update_col !== false && $update_val !== false) {
                            $query = "UPDATE `$this->dbtable` SET `$update_col`='$update_val' WHERE `id`={$this->p->r} LIMIT 1";
                            $wpdb->query($query);
                            echo $show_val;
                        }
                        
                        exit();
                        break;
                }
            }
			
            if ( isset($this->p->delete_reviews) && is_array($this->p->delete_reviews) && count($this->p->delete_reviews) ) {
                
                foreach ($this->p->delete_reviews as $i => $rid) {
                    $this->p->delete_reviews[$i] = intval($rid);
                }
				
                if (isset($this->p->act2)) { $this->p->action = $this->p->action2; }
				
                switch ($this->p->action) {
                    case 'bapprove':
                        $wpdb->query("UPDATE `$this->dbtable` SET `status`=1 WHERE `id` IN(".implode(',',$this->p->delete_reviews).")");
                        break;
                    case 'bunapprove':
                        $wpdb->query("UPDATE `$this->dbtable` SET `status`=0 WHERE `id` IN(".implode(',',$this->p->delete_reviews).")");
                        break;
                    case 'btrash':
                        $wpdb->query("UPDATE `$this->dbtable` SET `status`=2 WHERE `id` IN(".implode(',',$this->p->delete_reviews).")");
                        break;
                    case 'bdelete':
                        $wpdb->query("DELETE FROM `$this->dbtable` WHERE `id` IN(".implode(',',$this->p->delete_reviews).")");
                        break;
                }
            }
			
            $this->force_update_cache(); /* update any caches */            
            $this->parentClass->wpcr_redirect("?page=wpcr_view_reviews&review_status={$this->p->review_status}");
        }
        /* end - actions */
        
        /* begin - searching */
        if ($this->p->review_status == -1) {
            $sql_where = '-1=-1';
        } else {
            $sql_where = 'status='.$this->p->review_status;
        }
        
        $and_clause = '';
        if ($this->p->s != '') { /* searching */
            $this->p->s = '%'.$this->p->s.'%';
            $sql_where = '-1=-1';
            $this->p->review_status = -1;
            $and_clause = "AND (`name` LIKE %s
            					OR `email` LIKE %s
            					OR `orderID` LIKE %s
            					OR `text` LIKE %s 
            					OR `date_time` LIKE %s
            					OR `page_name` LIKE %s
            					OR `price` LIKE %s
            					OR `cost` LIKE %s
            					OR `hours` LIKE %s
            					OR `phone` LIKE %s
            					OR `phone2` LIKE %s
            					OR `city` LIKE %s
            					OR `last_name` LIKE %s
            					OR `first_name` LIKE %s
            					OR `middle_name` LIKE %s
            					OR `birth_date` LIKE %s
            					OR `birth_place` LIKE %s
            					OR `doc_serial` LIKE %s
            					OR `doc_number` LIKE %s
            					OR `issueDate` LIKE %s
            					OR `whoIssue` LIKE %s
            					OR `subCode` LIKE %s
            					OR `change_lastName` LIKE %s
            					OR `doc_change_lastName` LIKE %s
            					OR `adress` LIKE %s
            					OR `index` LIKE %s
            					OR `adress2` LIKE %s
            					OR `index2` LIKE %s
            					OR `education` LIKE %s
            					OR `institution` LIKE %s
            					OR `graduated` LIKE %s
            					OR `speciality` LIKE %s
            					OR `qualification` LIKE %s
            					OR `diplom` LIKE %s
            					OR `position` LIKE %s
            					OR `start_date` LIKE %s
            					)";
            $and_clause = $wpdb->prepare($and_clause,
            							$this->p->s,
            							$this->p->s,
            							$this->p->s,
            							$this->p->s,
            							$this->p->s,
            							$this->p->s,
            							$this->p->s,
            							$this->p->s,
            							$this->p->s,
            							$this->p->s,
            							$this->p->s,
            							$this->p->s,
            							$this->p->s,
            							$this->p->s,
            							$this->p->s,
            							$this->p->s,
            							$this->p->s,
            							$this->p->s,
            							$this->p->s,
            							$this->p->s,
            							$this->p->s,
            							$this->p->s,
            							$this->p->s,
            							$this->p->s,
            							$this->p->s,
            							$this->p->s,
            							$this->p->s,
            							$this->p->s,
            							$this->p->s,
            							$this->p->s,
            							$this->p->s,
            							$this->p->s,
            							$this->p->s,
            							$this->p->s,
            							$this->p->s,
            							$this->p->s,
            							$this->p->s,
            							$this->p->s,
            							$this->p->s
            							);
            
            $query = "SELECT 
                `id`,
                `date_time`,
                `orderID`,
                `name`,
                `email`,
                `text`,
                `status`,
                `page_name`,
                `price`,
                `cost`,
                `hours`,
                `phone`,
                `phone2`,
				`city`,
                `last_name`,
                `first_name`,
                `middle_name`,
                `birth_date`,
                `birth_place`,
                `doc_serial`,
                `doc_number`,
                `issueDate`,
                `whoIssue`,
                `subCode`,
                `change_lastName`,
                `doc_change_lastName`,
                `index`,
                `adress`,
                `index2`,
                `adress2`,
                `education`,
                `institution`,
                `graduated`,
                `speciality`,
                `qualification`,
                `diplom`,
                `position`,
                `start_date`

                FROM `$this->dbtable` WHERE $sql_where $and_clause ORDER BY `id` DESC"; 
            
            $reviews = $wpdb->get_results($query);
            $total_reviews = 0; /* no pagination for searches */
        }
        /* end - searching */
        else
        {
            $arr_Reviews = $this->parentClass->get_reviews(-1,$this->page,$this->options['reviews_per_page'],$this->p->review_status);
            $reviews = $arr_Reviews[0];
            $total_reviews = $arr_Reviews[1];
        }
		
        $status_text = "";
        switch ($this->p->review_status)
        {
            case -1:
                $status_text = 'Submitted';
                break;
            case 0:
                $status_text = 'Pending';
                break;
            case 1:
                $status_text = 'Approved';
                break;
            case 2:
                $status_text = 'Trashed';
                break;
        }
        
        $pending_count = $wpdb->get_results("SELECT COUNT(*) AS `count_pending` FROM `$this->dbtable` WHERE `status`=0");
        $pending_count = $pending_count[0]->count_pending;
		
        $approved_count = $wpdb->get_results("SELECT COUNT(*) AS `count_approved` FROM `$this->dbtable` WHERE `status`=1");
        $approved_count = $approved_count[0]->count_approved;

        $trash_count = $wpdb->get_results("SELECT COUNT(*) AS `count_trash` FROM `$this->dbtable` WHERE `status`=2");
        $trash_count = $trash_count[0]->count_trash;
        ?>
        <div id="wpcr_respond_1" class="wrap">
            <div class="icon32" id="icon-edit-comments"><br /></div>
            <h2>Заявки - <?php echo $status_text; ?> Reviews</h2>
            
              <ul class="subsubsub">
                <li class="all"><a <?php if ($this->p->review_status == -1) { echo 'class="current"'; } ?> href="?page=wpcr_view_reviews&amp;review_status=-1">All</a> |</li>
                <li class="moderated"><a <?php if ($this->p->review_status == 0) { echo 'class="current"'; } ?> href="?page=wpcr_view_reviews&amp;review_status=0">Pending 
                    <span class="count">(<span class="pending-count"><?php echo $pending_count;?></span>)</span></a> |
                </li>
                <li class="approved"><a <?php if ($this->p->review_status == 1) { echo 'class="current"'; } ?> href="?page=wpcr_view_reviews&amp;review_status=1">Approved
                    <span class="count">(<span class="pending-count"><?php echo $approved_count;?></span>)</span></a> |
                </li>
                <li class="trash"><a <?php if ($this->p->review_status == 2) { echo 'class="current"'; } ?> href="?page=wpcr_view_reviews&amp;review_status=2">Trash</a>
                    <span class="count">(<span class="pending-count"><?php echo $trash_count;?></span>)</span></a>
                </li>
              </ul>

              <form method="GET" action="" id="search-form" name="search-form">
                  <p class="search-box">
                      <?php if ($this->p->s_orig): ?><span style='color:#c00;font-weight:bold;'>RESULTS FOR: </span><?php endif; ?>
                      <label for="comment-search-input" class="screen-reader-text">Search Reviews:</label> 
                      <input type="text" value="<?php echo $this->p->s_orig; ?>" name="s" id="comment-search-input" />
                      <input type="hidden" name="page" value="wpcr_view_reviews" />
                      <input type="submit" class="button" value="Search Reviews" />
                  </p>
              </form>

              <form method="POST" action="?page=wpcr_view_reviews" id="comments-form" name="comments-form">
              <input type="hidden" name="review_status" value="<?php echo $this->p->review_status; ?>" />
              <div class="tablenav">
                <div class="alignleft actions">
                      <select name="action">
                            <option selected="selected" value="-1">Bulk Actions</option>
                            <option value="bunapprove">Unapprove</option>
                            <option value="bapprove">Approve</option>
                            <option value="btrash">Move to Trash</option>
                            <option value="bdelete">Delete Forever</option>
                      </select>&nbsp;
                      <input type="submit" class="button-secondary apply" name="act" value="Apply" id="doaction" />
                </div><br class="clear" />
              </div>
			  
              <div class="clear"></div>
              <table cellspacing="0" class="widefat comments fixed">
                <thead>
                  <tr>
                    <th style="" class="manage-column column-cb check-column" id="cb" scope="col"><input type="checkbox" /></th>
                    <th style="" class="manage-column column-author" id="author" scope="col">Author</th>
                    <th style="" class="manage-column column-comment" id="comment" scope="col">Review</th>
                  </tr>
                </thead>

                <tfoot>
                  <tr>
                    <th style="" class="manage-column column-cb check-column" scope="col"><input type="checkbox" /></th>
                    <th style="" class="manage-column column-author" scope="col">Author</th>
                    <th style="" class="manage-column column-comment" scope="col">Review</th>
                  </tr>
                </tfoot>

                <tbody class="list:comment" id="the-comment-list">
                  <?php
                  if (count($reviews) == 0) {
                      ?>
                        <tr><td colspan="3" align="center"><br />There are no <strong><?php echo $status_text; ?></strong> reviews yet.<br /><br /></td></tr>
                      <?php
                  }
                                    
                  foreach ($reviews as $review)
                  {                    
                      $rid = $review->id;
                      $update_path = get_admin_url()."admin-ajax.php?page=wpcr_view_reviews&r=$rid&action=update_field";
                      $hash = md5( strtolower( trim( $review->email ) ) );
                      $review->text = stripslashes($review->text);
                      $review->name = stripslashes($review->name);
                      // if ($review->name == '') { $review->name = 'Anonymous'; }
                      $text = nl2br($review->text);
                      $text = str_replace( array("\r\n","\r","\n") , "" , $text );
                      // continue; /* page no longer exists */
                  ?>
                      <tr class="approved" id="review-<?php echo $rid;?>">
                        <th class="check-column" scope="row"><input type="checkbox" value="<?php echo $rid;?>" name="delete_reviews[]" /></th>
                        <td class="author column-author">
                            <!-- <img width="32" height="32" class="avatar avatar-32 photo" src= -->
                            <!-- "http://1.gravatar.com/avatar/<?php echo $hash; ?>?s=32&amp;d=http%3A%2F%2F1.gravatar.com%2Favatar%2Fad516503a11cd5ca435acc9bb6523536%3Fs%3D32&amp;r=G" -->
                            <!-- alt="" />&nbsp;<span style="font-weight:bold;" class="best_in_place" data-url='<?php echo $update_path; ?>' data-object='json' data-attribute='name'> -->
                            <?php if ($review->name) : ?>
                            	<?= $review->name; ?>
                        	<?php else : ?>
								<?= $review->last_name . ' ' . $review->first_name . ' ' . $review->middle_name ?>
                        	<?php endif ?>


                            <!-- </span> -->
                            <br />
                            <a href="mailto:<?php echo $review->email; ?>"><?php echo $review->email; ?></a><br />
                            <?php
                            $custom_count = count($this->options['field_custom']); /* used for insert as well */
                            $custom_unserialized = @unserialize($review->custom_fields);
                            if ($custom_unserialized !== false)
                            {							
                                for ($i = 0; $i < $custom_count; $i++)
                                {
                                    $custom_field_name = $this->options['field_custom'][$i];
                                    if ( isset($custom_unserialized[$custom_field_name]) ) {
                                        $custom_value = $custom_unserialized[$custom_field_name];
                                        if ($custom_value != '')
                                        {
                                            echo "$custom_field_name: <span class='best_in_place' data-url='$update_path' data-object='json' data-attribute='custom_$i'>$custom_value</span><br />";
                                        }
                                    }
                                }
                            }
                            ?>
                        </td>
                        <td class="comment column-comment">
                           <div class="wpcr-submitted-on">
	                        	<?php 
	                        	$dnum=$review->id;
						        if ($dnum > 2807) {
						            $dnum = "СФ-" . str_pad(($dnum - 2807), 5, "0", STR_PAD_LEFT);
						        } else {
						            $dnum = "С-$dnum";
						        }

	                        	?>
	                        	<?php if($review->birth_date) : ?>
	                        	Заявка №<?php echo $dnum;?><br><br>
	                        	<a href="/toprint/statement.php?info=<?php echo $review->id; ?>" target="_blank">Заявление на поступление</a>
	                        	<br>
	                        	<a href="/toprint/contract.php?info=<?php echo $review->id; ?>" target="_blank">Договор на обучение</a>
	                        	<br>
	                        	<a href="/toprint/receipt.php?info=<?php echo $review->id; ?>" target="_blank">Квитанция на оплату</a>
	                        	<br>
	                        	<a href="/toprint/act.php?info=<?php echo $review->id; ?>" target="_blank">Акт</a>
	                        	<br><br>
								<?php endif; ?>

	                            <span style="font-size:13px;font-weight:bold;">Дата: </span>
	                            <?php echo date("d-m-Y H:i:s ",strtotime($review->date_time)); ?></a>
	                            <br />
	                            <span style="font-size:13px;font-weight:bold;">Курс (страница): </span>
	                            <?php echo $review->page_name; ?>


								<?php if($review->price) : ?>
		                            <br />
		                            <span style="font-size:13px;font-weight:bold;">Цена: </span>
		                            <?php echo $review->price; ?> руб.
	                            <?php endif; ?> 
				
								<?php if($review->hours) : ?>
									<br />
		                            <span style="font-size:13px;font-weight:bold;">Длительность: </span>
		                            <?php echo $review->hours; ?>
	                            <?php endif; ?> 

	                            <?php if ($review->birth_date) : ?>
									<br />
									<br />
		                            <span style="font-size:13px;font-weight:bold;">Дата рождения: </span>
		                            <?php echo $review->birth_date; ?>
		                        <?php endif; ?>

		                        <?php if ($review->city) : ?>
									<br />
									<br />
		                            <span style="font-size:13px;font-weight:bold;">Город: </span>
		                            <?php echo $review->city; ?>
		                        <?php endif; ?>


								<?php if ($review->phone) : ?>
									<br />
		                            <span style="font-size:13px;font-weight:bold;">Телефон: </span>
		                            <?php echo $review->phone; ?>
		                        <?php endif; ?>

		                        <?php if ($review->phone2) : ?>
									<br />
		                            <span style="font-size:13px;font-weight:bold;">Телефон 2: </span>
		                            <?php echo $review->phone2; ?>
		                        <?php endif; ?>

		                        <?php if ($review->birth_date) : ?>
									<br />
		                            <span style="font-size:13px;font-weight:bold;">Дата рождения: </span>
		                            <?php echo $review->birth_date; ?>
		                        <?php endif; ?>

		                        <?php if ($review->birth_place) : ?>
									<br />
		                            <span style="font-size:13px;font-weight:bold;">Место рождения: </span>
		                            <?php echo $review->birth_place; ?>
		                        <?php endif; ?>
		                        <br />

		                        <?php if ($review->doc_serial) : ?>
									<br />
		                            <span style="font-size:13px;font-weight:bold;">Паспорт серия: </span>
		                            <?php echo $review->doc_serial; ?>
		                        <?php endif; ?>

		                        <?php if ($review->doc_number) : ?>
									<br />
		                            <span style="font-size:13px;font-weight:bold;">Паспорт номер: </span>
		                            <?php echo $review->doc_number; ?>
		                        <?php endif; ?>

		                        <?php if ($review->issueDate) : ?>
									<br />
		                            <span style="font-size:13px;font-weight:bold;">Дата выдачи: </span>
		                            <?php echo $review->issueDate; ?>
		                        <?php endif; ?>

		                        <?php if ($review->whoIssue) : ?>
									<br />
		                            <span style="font-size:13px;font-weight:bold;">Кем выдан: </span>
		                            <?php echo $review->whoIssue; ?>
		                        <?php endif; ?>

		                        <?php if ($review->subCode) : ?>
									<br />
		                            <span style="font-size:13px;font-weight:bold;">Код подразделения: </span>
		                            <?php echo $review->subCode; ?>
		                        <?php endif; ?>
		                        <br />

		                        <?php if ($review->change_lastName) : ?>
									<br />
		                            <span style="font-size:13px;font-weight:bold;">Фамилию: </span>
		                            <?php echo $review->change_lastName; ?>
		                        <?php endif; ?>

		                        <?php if ($review->doc_change_lastName) : ?>
									<br />
		                            <span style="font-size:13px;font-weight:bold;">Документ о смене фамилии: </span>
		                            <?php echo $review->doc_change_lastName; ?>
		                        <?php endif; ?>

		                        <?php if ($review->index) : ?>
			                        <br />
			                        <br />
			                        <span style="font-size:15px;font-weight:bold; color: #a7a7a7;">Адрес регистрации как в паспорте: </span>
									<br />
		                            <span style="font-size:13px;font-weight:bold;">Индекс: </span>
		                            <?php echo $review->index; ?>
		                        <?php endif; ?>

		                        <?php if ($review->adress) : ?>
									<br />
		                            <span style="font-size:13px;font-weight:bold;">Адресс: </span>
		                            <?php echo $review->adress; ?>
		                        <?php endif; ?>


		                        <?php if ($review->index2) : ?>
			                        <br />
			                        <br />
		                        <span style="font-size:15px;font-weight:bold; color: #a7a7a7;">Адрес фактического проживания: </span>
									<br />
		                            <span style="font-size:13px;font-weight:bold;">Индекс: </span>
		                            <?php echo $review->index2; ?>
		                        <?php endif; ?>

		                        <?php if ($review->adress2) : ?>
									<br />
		                            <span style="font-size:13px;font-weight:bold;">Адресс: </span>
		                            <?php echo $review->adress2; ?>
		                        <?php endif; ?>

		                        <?php if ($review->education) : ?>
			                        <br />
									<br />
		                            <span style="font-size:13px;font-weight:bold;">Образование: </span>
		                            <?php echo $review->education; ?>
		                        <?php endif; ?>

		                        <?php if ($review->institution) : ?>
									<br />
		                            <span style="font-size:13px;font-weight:bold;">Что закончил: </span>
		                            <?php echo $review->institution; ?>
		                        <?php endif; ?>

		                        <?php if ($review->graduated) : ?>
									<br />
		                            <span style="font-size:13px;font-weight:bold;">Год окончания: </span>
		                            <?php echo $review->graduated; ?>
		                        <?php endif; ?>

		                        <?php if ($review->speciality) : ?>
									<br />
		                            <span style="font-size:13px;font-weight:bold;">Специальность: </span>
		                            <?php echo $review->speciality; ?>
		                        <?php endif; ?>

		                        <?php if ($review->qualification) : ?>
									<br />
		                            <span style="font-size:13px;font-weight:bold;">Квалификация: </span>
		                            <?php echo $review->qualification; ?>
		                        <?php endif; ?>

		                        <?php if ($review->diplom) : ?>
									<br />
		                            <span style="font-size:13px;font-weight:bold;">Диплом (номер): </span>
		                            <?php echo $review->diplom; ?>
		                        <?php endif; ?>

		                        <?php if ($review->position) : ?>
									<br />
									<br />
		                            <span style="font-size:13px;font-weight:bold;">Должность: </span>
		                            <?php echo $review->position; ?>
		                        <?php endif; ?>

					
		                        <?php if ($review->start_date) : ?>
			                        <br />
									<br />
		                            <span style="font-size:13px;font-weight:bold;">Желаемая дата начала обучения: </span>
		                            <?php echo $review->start_date; ?>
		                        <?php endif; ?>

	                        </div>
                        <p>
							 <?php if ($text) : ?>
                                <span style="font-size:13px;font-weight:bold;">Сообщение: </span>
                                <?php echo $text; ?>
                            <?php endif; ?>

                        </p>
                          <div class="row-actions">
                            <span class="approve <?php if ($review->status == 0 || $review->status == 2) { echo 'wpcr_show'; } else { echo 'wpcr_hide'; }?>"><a title="Mark as Approved"
                            href="?page=wpcr_view_reviews&amp;action=approvereview&amp;r=<?php echo $rid;?>&amp;review_status=<?php echo $this->p->review_status;?>">
                            Отметить как прочитанное</a>&nbsp;|&nbsp;</span>
                            <span class="unapprove <?php if ($review->status == 1 || $review->status == 2) { echo 'wpcr_show'; } else { echo 'wpcr_hide'; }?>"><a title="Mark as Unapproved"
                            href="?page=wpcr_view_reviews&amp;action=unapprovereview&amp;r=<?php echo $rid;?>&amp;review_status=<?php echo $this->p->review_status;?>">
                            Отметить как непрочитанное</a><?php if ($review->status != 2): ?>&nbsp;|&nbsp;<?php endif; ?></span>
                            <span class="trash <?php if ($review->status == 2) { echo 'wpcr_hide'; } else { echo 'wpcr_show'; }?>"><a title="Move to Trash" 
                            href= "?page=wpcr_view_reviews&amp;action=trashreview&amp;r=<?php echo $rid;?>&amp;review_status=<?php echo $this->p->review_status;?>">
                            Переместить в корзину</a><?php if ($review->status != 2): ?>&nbsp;|&nbsp;<?php endif; ?></span>
                            <span class="trash <?php if ($review->status == 2) { echo 'wpcr_hide'; } else { echo 'wpcr_show'; }?>"><a title="Delete Forever" 
                            href= "?page=wpcr_view_reviews&amp;action=deletereview&amp;r=<?php echo $rid;?>&amp;review_status=<?php echo $this->p->review_status;?>">
                            Удалить навсегда</a></span>
                          </div>
                        </td>
                      </tr>
                  <?php
                  }
                  ?>
                </tbody>
              </table>

              <div class="tablenav">
                <div class="alignleft actions" style="float:left;">
                      <select name="action2">
                            <option selected="selected" value="-1">Выберите действие</option>
                            <option value="bunapprove">Отменить</option>
                            <option value="bapprove">Подтвердить</option>
                            <option value="btrash">Переместить в корзину</option>
                            <option value="bdelete">Удалить навсегда</option>
                      </select>&nbsp;
                      <input type="submit" class="button-secondary apply" name="act2" value="Apply" id="doaction2" />
                </div>
                <div class="alignleft actions" style="float:left;padding-left:20px;"><?php echo $this->parentClass->pagination($total_reviews, $this->options['reviews_per_page']); ?></div>  
                <br class="clear" />
              </div>
            </form>

            <div id="ajax-response"></div>
          </div>
        <?php
    }
	
}

if (!defined('IN_WPCR_ADMIN')) {
    global $WPCustomerReviews, $WPCustomerReviewsAdmin;
    $WPCustomerReviewsAdmin = new WPCustomerReviewsAdmin($WPCustomerReviews);
}
?>