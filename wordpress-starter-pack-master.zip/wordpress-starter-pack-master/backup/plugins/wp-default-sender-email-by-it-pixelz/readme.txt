=== Wp Default Sender Email by IT Pixelz ===
Contributors: itpixelz
Donate link: http://www.itpixelz.com/
Tags: email, mail, wp mail, default mail, wp_mail, email from
Requires at least: 3.0.1
Tested up to: 4.2.2
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Get rid of default email from like this wordpress@domain.com, use your own!

== Description ==

Change your wordpress default sender email ID to your own to look like more professional. By default its wordpress@domain.com but right now using this plugin you may change the name of the sender and the email ID from too.

== Installation ==

1. Download the plugin zip file and extract it from zip folder and uplaod  `wp_default_sender_email_itpixelz` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to settings of the plugin and edit options and save it.
4. Thats it!!! Enjoy :)


== Screenshots ==

1. Go to the Settings link from left side bar in wp-admin and then go to the link "WP Default Mail" and then change the settings as per your requirement.


