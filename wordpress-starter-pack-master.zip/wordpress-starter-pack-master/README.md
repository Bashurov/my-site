# wordpress-starter-pack
wordpress starter pack with -sass -aletheme -js_plugins
